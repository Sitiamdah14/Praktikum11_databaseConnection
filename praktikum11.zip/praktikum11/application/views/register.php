<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Blank Page</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('plugins/fontawesome-free/css/all.min.css')?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('dist/css/adminlte.min.css')?>">
</head>
<body class="p-5">
  
<h1 class="pb-3 text-center text-danger text-bold">REGISTRASI</h1>
<?php echo form_open('register/save')?>
  <div class="form-group row">
    <label class="col-4 col-form-label" for="username">Username</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-address-card"></i>
          </div>
        </div> 
        <input id="username" name="username" type="text" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="email" class="col-4 col-form-label">Email</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-address-book"></i>
          </div>
        </div> 
        <input id="email" name="email" type="text" class="form-control" 
        required="required" aria-describedby="emailHelpBlock">
      </div> 
    </div>
  </div>
  <div class="form-group row">
    <label for="password" class="col-4 col-form-label">Password</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-adjust"></i>
          </div>
        </div> 
        <input id="password" name="password" type="password" class="form-control"
         required="required" aria-describedby="passwordHelpBlock">
      </div> 
    </div>
  </div>
  <div class="form-group row">
    <label for="cnfrmpassword" class="col-4 col-form-label">Confirm Password</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-adjust"></i>
          </div>
        </div> 
        <input id="cnfrmpassword" name="cnfrmpassword" type="password" class="form-control" required="required" aria-describedby="confirmHelpBlock">
      </div> 
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button type="submit" onclick="return checkPassword()" class="btn btn-success">Register</button>
    </div>
  </div>
  <h6 class="text-right pt-3">Jika sudah memiliki akun silahkan kembali ke menu</h6>
  <div class="offset-11 col-1 btn btn-right">
        <a href="<?php echo base_url('index.php/login')?>" class="btn btn-block btn-primary">Login</a>
    </div>
  <?php echo form_close()?>


  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- register js -->
<script src="<?php echo base_url('dist/js/script.js')?>"></script>
<!-- jQuery -->
<script src="<?php echo base_url('plugins/jquery/jquery.min.js')?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url('plugins/bootstrap/js/bootstrap.bundle.min.js')?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('dist/js/adminlte.min.js')?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('dist/js/demo.js')?>"></script>
</body>
</html>
